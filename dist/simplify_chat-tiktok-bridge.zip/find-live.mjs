﻿import { TikTokLiveConnection } from "tiktok-live-connector";
const names=["tv_asahi_news","nasa","redbull","fifa","netflix","mrbeast","tiktok","spotify","cbsnews","bloomberg","weatherchannel","skynews"];
for(const name of names){ const c=new TikTokLiveConnection(name,{}); try{ const live=await Promise.race([c.fetchIsLive(),new Promise((_,rej)=>setTimeout(()=>rej(new Error("timeout")),10000))]); console.log(name,live); if(live){console.log("FOUND",name);break;} }catch(e){console.log(name,"ERR",e?.message??e);} }
