﻿import { TikTokLiveConnection } from "tiktok-live-connector";
const c=new TikTokLiveConnection("mplmy",{});
try{const info=await c.fetchRoomInfo(); console.log("room",info?.data?.roomId||info?.roomId, "title", (info?.data?.title||info?.title||"").slice(0,80)); const users=info?.data?.stats?.total_user||info?.data?.user_count||info?.stats?.total_user; console.log("stats",JSON.stringify(info?.data?.stats||info?.stats||{}).slice(0,300));}catch(e){console.log("ERR",e?.message??e)}
console.log("islive", await c.fetchIsLive().catch(e=>"ERR "+e.message));
